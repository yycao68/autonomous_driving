"""
FR3 end-effector position-Hessian norm ||H_p||_F (Section IV.A).

The first-order safe-corridor rows linearize the forward kinematics; the
second-order Taylor remainder is bounded by (1/2)||H_p||_F ||dq||^2, where
H_p(q) is the position Hessian (d^2 p_ee / dq_i dq_j, a 3x7x7 tensor).  This
script computes ||H_p||_F by central-difference differentiation of the
translational Jacobian over the FR3 joint range and reports the distribution
used to set the conservative obstacle margin in Section IV.A.
"""
import numpy as np
from fr3_kinematics import jacobian_v
from di_planner import FR3_QMIN, FR3_QMAX


def hessian_norm(q, eps=1e-5):
    """||H_p(q)||_F via central difference of the translational Jacobian.

    H[k,i,j] = d J_v[k,i] / d q_j ; central-differenced column by column.
    """
    H = np.zeros((3, 7, 7))
    for j in range(7):
        dq = np.zeros(7); dq[j] = eps
        H[:, :, j] = (jacobian_v(q + dq) - jacobian_v(q - dq)) / (2 * eps)
    return np.linalg.norm(H)


def main(n=5000, seed=0):
    rng = np.random.default_rng(seed)
    Q = rng.uniform(FR3_QMIN, FR3_QMAX, size=(n, 7))
    norms = np.array([hessian_norm(q) for q in Q])
    print(f"FR3 ||H_p||_F over {n} uniform-joint-range configs [m/rad^2]")
    print(f"  mean   = {norms.mean():.3f}")
    print(f"  median = {np.median(norms):.3f}")
    print(f"  p95    = {np.percentile(norms, 95):.3f}")
    print(f"  max    = {norms.max():.3f}")
    # worked margin example used in Section IV.A: 50% joint speed, N=20 (0.2 s)
    from di_planner import FR3_VMAX
    dt, N = 0.01, 20
    dq = 0.5 * FR3_VMAX * N * dt                     # per-joint excursion
    Hp95 = np.percentile(norms, 95)
    eps_2 = 0.5 * Hp95 * np.linalg.norm(dq) ** 2     # Euclidean-norm bound
    eps_inf = 0.5 * Hp95 * dq.max() ** 2             # max-joint heuristic
    print(f"\n50%-speed, N=20 horizon excursion:")
    print(f"  ||dq||_2 = {np.linalg.norm(dq):.3f} rad, ||dq||_inf = {dq.max():.3f} rad")
    print(f"  eps_p (||dq||_2 bound)  = {eps_2:.3f} m")
    print(f"  eps_p (max-joint heur.) = {eps_inf:.3f} m")


if __name__ == "__main__":
    main()
