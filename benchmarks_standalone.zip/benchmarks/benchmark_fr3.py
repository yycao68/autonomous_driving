"""
FR3 benchmark suite: time-first DI-QP planner  vs  path-first TOTG/TOPP.

Both planners receive the SAME waypoints and the SAME kinematic limits and emit
(q, q_dot, q_ddot) sampled at the same dt.  We then score:

  T          time to goal           (TOTG is time-optimal -> lower bound)
  peak|a|/amax  worst accel ratio    (>1 means the limit was BROKEN on output)
  a-viol     # output samples over the accel limit
  v-viol     # output samples over the velocity limit
  jerk_rms / jerk_peak               smoothness of the emitted trajectory
  a-jump     max |a_{k+1}-a_k|       acceleration DISCONTINUITY (blend seams)
  min s_dot / max 1/s_dot   (TOTG)   s->t conditioning (rest/tight-blend blow-up)
  compute    DI: ms/cycle (online)   TOTG: ms full build (offline, must redo on change)

Run:  python3 benchmark_fr3.py
"""

import numpy as np
from di_planner import plan_di, FR3_VMAX, FR3_AMAX
from di_totg import plan_totg


def metrics(res, vmax, amax, dt):
    A, V = res["A"], res["V"]
    T = res["t"][-1]
    peak_a = np.abs(A).max(0)
    peak_v = np.abs(V).max(0)
    a_ratio = float((peak_a / amax).max())          # >1 == limit violated
    v_ratio = float((peak_v / vmax).max())
    a_viol = int((np.abs(A) - amax > 1e-3).sum())
    v_viol = int((np.abs(V) - vmax > 1e-3).sum())
    jerk = np.diff(A, axis=0) / dt
    jerk_rms = float(np.sqrt((jerk ** 2).mean())) if jerk.size else 0.0
    jerk_peak = float(np.abs(jerk).max()) if jerk.size else 0.0
    a_jump = float(np.abs(np.diff(A, axis=0)).max()) if A.shape[0] > 1 else 0.0
    return dict(T=T, a_ratio=a_ratio, v_ratio=v_ratio, a_viol=a_viol,
                v_viol=v_viol, jerk_rms=jerk_rms, jerk_peak=jerk_peak,
                a_jump=a_jump)


def run_pair(name, wps, n, dt=0.01, max_dev=0.1, di_kw=None):
    vmax, amax = FR3_VMAX[:n], FR3_AMAX[:n]
    di_kw = di_kw or {}
    di = plan_di(wps, dt=dt, vmax=vmax, amax=amax, **di_kw)
    tg = plan_totg(wps, dt=dt, vmax=vmax, amax=amax, max_dev=max_dev)
    md, mt = metrics(di, vmax, amax, dt), metrics(tg, vmax, amax, dt)
    md["compute"] = 1e3 * di["solve_t"].mean()      # ms / online cycle
    mt["compute"] = 1e3 * tg["build_t"]             # ms full offline build
    mt["min_sdot"] = tg["min_sdot"]
    mt["max_inv_sdot"] = tg["max_inv_sdot"]
    mt["min_blend_r"] = tg["min_blend_r"]
    mt["stalled"] = tg.get("stalled", False)
    return name, md, mt, di, tg


def print_row(label, md, mt):
    print(f"\n=== {label} ===")
    hdr = f"{'metric':<22}{'DI-QP (time-first)':>22}{'TOTG (path-first)':>22}"
    print(hdr); print("-" * len(hdr))
    rows = [
        ("time to goal T [s]", f"{md['T']:.3f}", f"{mt['T']:.3f}"),
        ("peak|a|/amax  (>1=BAD)", f"{md['a_ratio']:.3f}", f"{mt['a_ratio']:.3f}"),
        ("accel violations", f"{md['a_viol']}", f"{mt['a_viol']}"),
        ("vel violations", f"{md['v_viol']}", f"{mt['v_viol']}"),
        ("jerk RMS [rad/s^3]", f"{md['jerk_rms']:.1f}", f"{mt['jerk_rms']:.1f}"),
        ("jerk peak [rad/s^3]", f"{md['jerk_peak']:.0f}", f"{mt['jerk_peak']:.0f}"),
        ("accel jump [rad/s^2]", f"{md['a_jump']:.2f}", f"{mt['a_jump']:.2f}"),
        ("compute", f"{md['compute']:.3f} ms/cyc", f"{mt['compute']:.1f} ms build"),
    ]
    if "min_sdot" in mt:
        rows.append(("min s_dot (TOTG)", "n/a (no s)", f"{mt['min_sdot']:.4f}"))
        rows.append(("max 1/s_dot (TOTG)", "n/a (no s)",
                     f"{mt['max_inv_sdot']:.1f}"))
        rows.append(("s->t parameterization", "n/a (no s)",
                     "STALLED (singular)" if mt.get("stalled") else "ok"))
    for r in rows:
        print(f"{r[0]:<22}{r[1]:>22}{r[2]:>22}")


# ---------------------------------------------------------------------------
# Scenarios (7-DOF; stresses concentrated in joints 0-1 for interpretability)
# ---------------------------------------------------------------------------
def b1_point_to_point():
    z = np.zeros(7)
    W = np.array([z, [1.0, -0.6, 0.5, -0.8, 0.4, 0.3, -0.5]])
    return "B1  point-to-point (optimality-gap baseline)", W, 7, dict()


def b2_acute_corner(max_dev):
    z = np.zeros(7)
    W = np.array([
        z,
        [1.0, 0.0, 0.2, -0.3, 0.0, 0.0, 0.0],
        [0.4, 0.9, 0.2, -0.3, 0.0, 0.0, 0.0],   # sharp ~124 deg turn in q0-q1
    ])
    return f"B2  acute corner (max_dev={max_dev})", W, 7, dict()


def b3_near_reversal(max_dev):
    z = np.zeros(7)
    W = np.array([
        z,
        [1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
        [0.05, 0.05, 0.0, 0.0, 0.0, 0.0, 0.0],  # ~180 deg reversal -> r->0
    ])
    return f"B3  near-reversal / stop (max_dev={max_dev})", W, 7, dict()


def b4_dense_noisy(seed=0, M=24):
    rng = np.random.default_rng(seed)
    t = np.linspace(0, 1, M)
    base = np.column_stack([
        1.2 * np.sin(2 * np.pi * t),
        0.9 * np.sin(2 * np.pi * t + 0.7),
        0.6 * np.cos(2 * np.pi * t),
        -0.5 * np.sin(np.pi * t),
        0.4 * np.cos(3 * np.pi * t),
        0.3 * np.sin(2.5 * np.pi * t),
        -0.4 * np.cos(2 * np.pi * t),
    ])
    base[0] = 0.0
    noise = 0.06 * rng.standard_normal(base.shape)
    noise[0] = 0; noise[-1] = 0
    W = base + noise
    return "B4  dense noisy waypoints (24 pts)", W, 7, dict()


def reactivity_demo():
    """B5: cost of reacting to an online change (new goal mid-flight).

    DI-QP just changes the goal vector -> next QP cycle deflects (one solve).
    TOTG must rebuild path + re-run TOPP from scratch (full build).
    """
    z = np.zeros(7)
    W = np.array([z, [1.2, -0.4, 0.3, -0.5, 0.2, 0.2, -0.3]])
    n = 7
    vmax, amax = FR3_VMAX[:n], FR3_AMAX[:n]
    di = plan_di(W, dt=0.01, vmax=vmax, amax=amax)
    tg = plan_totg(W, dt=0.01, vmax=vmax, amax=amax)
    di_react = 1e3 * np.median(di["solve_t"])    # one cycle reaction latency
    tg_react = 1e3 * tg["build_t"]               # full pipeline rebuild
    print("\n=== B5  reactivity to an online change ===")
    print(f"DI-QP : react within ONE QP cycle      -> {di_react:.3f} ms")
    print(f"TOTG  : must rebuild path + re-time     -> {tg_react:.1f} ms")
    print(f"latency ratio (TOTG / DI)              -> {tg_react/di_react:.0f}x")


if __name__ == "__main__":
    np.set_printoptions(precision=3, suppress=True)

    name, W, n, kw = b1_point_to_point()
    _, md, mt, *_ = run_pair(name, W, n, di_kw=kw)
    print_row(name, md, mt)

    print("\n\n########## B2: acute corner, sweep blend tightness ##########")
    for dev in (0.20, 0.10, 0.05, 0.02):
        name, W, n, kw = b2_acute_corner(dev)
        _, md, mt, *_ = run_pair(name, W, n, max_dev=dev, di_kw=kw)
        print_row(name, md, mt)

    print("\n\n########## B3: near-reversal, sweep blend tightness ##########")
    for dev in (0.10, 0.05, 0.02):
        name, W, n, kw = b3_near_reversal(dev)
        _, md, mt, *_ = run_pair(name, W, n, max_dev=dev, di_kw=kw)
        print_row(name, md, mt)

    print("\n\n########## B4: dense noisy waypoints ##########")
    name, W, n, kw = b4_dense_noisy()
    _, md, mt, *_ = run_pair(name, W, n, max_dev=0.08, di_kw=kw)
    print_row(name, md, mt)

    reactivity_demo()
