"""
FR3 (Franka Research 3 / Panda) forward kinematics and geometric Jacobian.

Needed to exercise the Section IV task-space obstacle constraints on the real
7-DOF arm (so far they were only tested on a planar point robot).  Modified
(Craig) Denavit-Hartenberg parameters; flange/EE at the link-7 frame + 0.107 m.

Verified by finite-difference against the analytic Jacobian (see __main__).
"""
import numpy as np

# Panda/FR3 modified-DH: (a_{i-1}, alpha_{i-1}, d_i) ; theta_i = q_i
_DH = [
    (0.0,      0.0,      0.333),
    (0.0,     -np.pi/2,  0.0),
    (0.0,      np.pi/2,  0.316),
    (0.0825,   np.pi/2,  0.0),
    (-0.0825, -np.pi/2,  0.384),
    (0.0,      np.pi/2,  0.0),
    (0.088,    np.pi/2,  0.0),
]
_D_FLANGE = 0.107   # link7 frame -> end-effector


def _rotx(al):
    c, s = np.cos(al), np.sin(al)
    return np.array([[1, 0, 0, 0], [0, c, -s, 0], [0, s, c, 0], [0, 0, 0, 1.0]])

def _rotz(th):
    c, s = np.cos(th), np.sin(th)
    return np.array([[c, -s, 0, 0], [s, c, 0, 0], [0, 0, 1, 0], [0, 0, 0, 1.0]])

def _transx(a):
    T = np.eye(4); T[0, 3] = a; return T

def _transz(d):
    T = np.eye(4); T[2, 3] = d; return T


def fk_frames(q):
    """Modified-DH FK.  Returns the per-joint axis (z_i) and a point on it (p_i)
    -- taken in the frame *before* the theta_i rotation, which is the correct axis
    for the geometric Jacobian -- plus the EE position and full EE transform.

    Each link: ^{i-1}T_i = Rotx(alpha_{i-1}) Transx(a_{i-1}) Rotz(theta_i) Transz(d_i).
    """
    T = np.eye(4)
    axes, points = [], []
    for i in range(7):
        a, alpha, d = _DH[i]
        T = T @ _rotx(alpha) @ _transx(a)     # frame F'_i (before the joint rotation)
        axes.append(T[:3, 2].copy())          # joint i rotates about this z
        points.append(T[:3, 3].copy())
        T = T @ _rotz(q[i]) @ _transz(d)       # apply the joint
    T = T @ _transz(_D_FLANGE)                 # flange -> EE
    p_ee = T[:3, 3].copy()
    return axes, points, p_ee, T


def fk(q):
    """End-effector position (3,) in the base frame."""
    return fk_frames(q)[2]


def jacobian_v(q):
    """Translational geometric Jacobian J_v (3x7): dp_ee/dq."""
    axes, points, p_ee, _ = fk_frames(q)
    J = np.zeros((3, 7))
    for i in range(7):
        J[:, i] = np.cross(axes[i], p_ee - points[i])
    return J


if __name__ == "__main__":
    rng = np.random.default_rng(0)
    max_err = 0.0
    for _ in range(200):
        q = rng.uniform(-2.0, 2.0, 7)
        J = jacobian_v(q)
        Jfd = np.zeros((3, 7))
        eps = 1e-6
        for i in range(7):
            dq = np.zeros(7); dq[i] = eps
            Jfd[:, i] = (fk(q + dq) - fk(q - dq)) / (2 * eps)
        max_err = max(max_err, np.abs(J - Jfd).max())
    print(f"analytic vs finite-difference Jacobian: max error = {max_err:.2e}")
    print(f"FK at home q=0: p_ee = {np.round(fk(np.zeros(7)), 4)}")
    # sanity: Panda home EE is ~[0.088, 0, 0.926] (z = 0.333+0.316+0.384-0.107? check)
