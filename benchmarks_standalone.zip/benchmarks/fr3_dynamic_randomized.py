"""
Randomized FR3 dynamic-obstacle robustness benchmark.

This script reuses fr3_dynamic_obstacle.py, perturbing the start/goal joint
states and the obstacle crossing trajectory.  It reports distributional metrics
instead of a single run, backing Table "Randomized FR3 Dynamic-Obstacle
Robustness" in the reactive motion-planning paper (seed 7, 20 trials).

RECONSTRUCTION NOTE
-------------------
The original module was lost: it was never committed to either repository, and
only a stale __pycache__/fr3_dynamic_randomized.cpython-313.pyc remained in
autonomous_driving/benchmarks/.  An external review flagged the cited source as
absent.  This file was reconstructed from that bytecode -- the constants, call
order, RNG draw order, closure structure and print formatting below are read
directly off the disassembly, not guessed -- and then checked against the
published table.  See the paper's table and RECONSTRUCTION.md for the
agreement obtained.  It is byte-for-byte equivalent in behaviour as far as the
bytecode determines; comments and formatting are new.
"""
import numpy as np

import fr3_dynamic_obstacle as fdo

BASE_START = fdo.Q_START.copy()
BASE_GOAL = fdo.Q_GOAL.copy()
BASE_OBSTACLE_POS = fdo.obstacle_pos


def _make_obstacle_fn(q_start, q_goal, lateral, z0, speed):
    """Obstacle that crosses the straight-line midpoint of this trial's motion."""
    p0 = fdo.fk(q_start)
    pg = fdo.fk(q_goal)
    mid = 0.5 * (p0 + pg)

    def obstacle_pos(t):
        return mid + np.array([lateral[0], lateral[1], z0 - speed * t])

    return obstacle_pos


def _run_one(rng):
    """One randomized trial: jitter start/goal and the crossing, run both planners."""
    q_start = BASE_START + rng.normal(0.0, 0.035, size=7)
    q_goal = BASE_GOAL + rng.normal(0.0, 0.055, size=7)
    # Keep the elbow/wrist joints in a reachable band after jitter.
    q_goal[3] = np.clip(q_goal[3], -2.0, -0.6)
    q_goal[5] = np.clip(q_goal[5], 1.0, 2.2)

    lateral = rng.normal(0.0, 0.035, size=2)
    z0 = rng.uniform(0.24, 0.38)
    speed = rng.uniform(0.24, 0.42)

    fdo.Q_START = q_start
    fdo.Q_GOAL = q_goal
    fdo.obstacle_pos = _make_obstacle_fn(q_start, q_goal, lateral, z0, speed)

    qp = fdo.run_qp_fixed_sparsity()
    bl = fdo.run_baseline()
    return qp, bl


def _summarize(vals):
    vals = np.asarray(vals, float)
    return (vals.mean(),
            vals.std(ddof=1) if len(vals) > 1 else 0.0,
            vals.min(),
            vals.max())


def main(n_trials=20, seed=7):
    rng = np.random.default_rng(seed)
    qp_rows, bl_rows = [], []

    for i in range(n_trials):
        qp, bl = _run_one(rng)
        qp_rows.append(qp)
        bl_rows.append(bl)
        print(f"trial {i + 1:02d}/{n_trials}: "
              f"QP reached={qp['reached']} clr={qp['min_clr']:.3f} "
              f"v/a viol={qp['v_viol']}/{qp['a_viol']} "
              f"max solve={1000.0 * qp['solve_t'].max():.1f} ms | "
              f"baseline reached={bl['reached']} clr={bl['min_clr']:.3f} "
              f"v/a viol={bl['v_viol']}/{bl['a_viol']}")

    # Restore the module globals this script mutated.
    fdo.Q_START = BASE_START.copy()
    fdo.Q_GOAL = BASE_GOAL.copy()
    fdo.obstacle_pos = BASE_OBSTACLE_POS

    qp_clr = np.array([r["min_clr"] for r in qp_rows], float)
    bl_clr = np.array([r["min_clr"] for r in bl_rows], float)
    qp_ok = np.array([bool(r["reached"]) for r in qp_rows])
    bl_ok = np.array([bool(r["reached"]) for r in bl_rows])
    solve = np.concatenate([np.asarray(r["solve_t"], float) for r in qp_rows])

    qp_c = _summarize(qp_clr)
    bl_c = _summarize(bl_clr)

    print("\n" + "=" * 78)
    print(f"RANDOMIZED FR3 DYNAMIC OBSTACLE ({n_trials} trials, seed={seed})")
    print("=" * 78)
    print(f"{'metric':<32}{'DI-QP':>22}{'reactive baseline':>22}")
    print("-" * 78)
    print(f"{'success rate':<32}{qp_ok.mean():>22.0%}{bl_ok.mean():>22.0%}")
    print(f"{'min clearance, mean±std [m]':<32}"
          f"{f'{qp_c[0]:.3f} ± {qp_c[1]:.3f}':>22}"
          f"{f'{bl_c[0]:.3f} ± {bl_c[1]:.3f}':>22}")
    print(f"{'min clearance, worst [m]':<32}{qp_c[2]:>22.3f}{bl_c[2]:>22.3f}")
    print(f"{'total velocity violations':<32}"
          f"{sum(r['v_viol'] for r in qp_rows):>22}"
          f"{sum(r['v_viol'] for r in bl_rows):>22}")
    print(f"{'total acceleration violations':<32}"
          f"{sum(r['a_viol'] for r in qp_rows):>22}"
          f"{sum(r['a_viol'] for r in bl_rows):>22}")
    print(f"{'max slack [m]':<32}"
          f"{max(r['max_slack'] for r in qp_rows):>22.4f}{'n/a':>22}")
    p95 = 1000.0 * np.percentile(solve, 95)
    smax = 1000.0 * solve.max()
    print(f"{'QP solve p95 / max [ms]':<32}"
          f"{f'{p95:.2f} / {smax:.2f}':>22}{'n/a':>22}")


if __name__ == "__main__":
    main()
