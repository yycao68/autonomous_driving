"""
MuJoCo physical comparison: execute the DI-QP vs TOTG reference on the FR3 with a
computed-torque controller, and show what the acceleration profiles do in physics.

Setup:
  * FR3 model (pHRI/simulation/models/franka_fr3/fr3.xml), actuators switched to pure
    torque (motor) mode; controller at 500 Hz (MuJoCo dt=2 ms).
  * Each planner runs at 100 Hz; its (q_d, q_dot_d, q_ddot_d) is zero-order-held across
    the 5 control sub-ticks (a realistic planner/controller rate split).
  * Computed torque:  tau = M(q) q_ddot_d + C(q,q_dot)q_dot + g(q) + Kp e + Kd e_dot,
    then CLIPPED to the FR3 joint torque limits.

The point: TOTG's q_ddot jumps at blend seams demand torque spikes -> saturation ->
tracking error; the DI reference is bounded and tracks within the limits.  Plots ->
mujoco_compare.png.
"""
import numpy as np
import mujoco
from pathlib import Path
from di_planner import plan_di, FR3_VMAX, FR3_AMAX
from di_totg import plan_totg
from benchmark_fr3 import b2_acute_corner

# Only autonomous_driving/paper/mp_main.tex (via the benchmarks/ shim) uses this
# script's figure; save straight into its simulationResults/ folder.
RESULTS_DIR = Path(__file__).parent.parent.parent / "autonomous_driving" / "simulationResults"

def _find_fr3_xml():
    """Locate the FR3 MuJoCo model without a machine-specific hardcoded path.

    Honors $FR3_XML, then searches up from this file for
    pHRI/simulation/models/franka_fr3/fr3.xml, then a couple of common roots.
    """
    import os
    env = os.environ.get("FR3_XML")
    if env and os.path.exists(env):
        return env
    rel = os.path.join("pHRI", "simulation", "models", "franka_fr3", "fr3.xml")
    here = os.path.dirname(os.path.abspath(__file__))
    cands = []
    d = here
    for _ in range(6):                      # walk up the tree (…/ai_learn/…)
        cands.append(os.path.join(d, rel))
        d = os.path.dirname(d)
    cands += [os.path.expanduser(os.path.join("~/ai_learn", rel))]
    for c in cands:
        if os.path.exists(c):
            return c
    raise FileNotFoundError(
        "FR3 model not found; set $FR3_XML to .../franka_fr3/fr3.xml")


XML = _find_fr3_xml()
TAU_MAX = np.array([87., 87., 87., 87., 12., 12., 12.])   # FR3 joint torque limits [Nm]
KP = np.array([150., 150., 150., 150., 80., 80., 80.])
KD = np.array([25., 25., 25., 25., 16., 16., 16.])
# planning acceleration limits kept dynamically feasible (well within torque capacity)
# so the DI reference never saturates -- only TOTG's seam spikes can.
AMAX_PLAN = np.array([6.0, 3.0, 4.0, 4.0, 8.0, 10.0, 10.0])

# Acute-corner waypoints VALID for the FR3 joint limits (around the home keyframe;
# joint4 in [-3.04,-0.15], joint6 in [0.54,4.52]).  Sharp turn in joints 0-1.
_HOME = np.array([0.0, 0.0, 0.0, -1.571, 0.0, 1.571, -0.785])
WAYPOINTS = np.array([
    _HOME,
    _HOME + np.array([1.0, 0.5, 0.2, 0.3, 0.2, 0.3, 0.2]),
    _HOME + np.array([0.3, 1.1, 0.2, 0.3, 0.2, 0.3, 0.2]),    # ~sharp corner in q0-q1
])


def load_torque_model():
    m = mujoco.MjModel.from_xml_path(XML)
    # convert position-servo actuators to pure torque (motor) actuators
    m.actuator_gaintype[:] = mujoco.mjtGain.mjGAIN_FIXED
    m.actuator_biastype[:] = mujoco.mjtBias.mjBIAS_NONE
    m.actuator_gainprm[:] = 0.0; m.actuator_gainprm[:, 0] = 1.0
    m.actuator_biasprm[:] = 0.0
    m.actuator_ctrllimited[:] = 0
    return m


def track(ref, dt_plan=0.01, clip=True):
    """Execute reference (Q,V,A at dt_plan) on FR3 with computed torque. Returns logs."""
    m = load_torque_model()
    d = mujoco.MjData(m)
    Q, V, A = ref["Q"], ref["V"], ref["A"]
    Fc = m.dof_frictionloss[:7].copy()               # Coulomb (dry) friction per joint
    d.qpos[:7] = Q[0]; d.qvel[:7] = 0.0
    mujoco.mj_forward(m, d)
    nsub = int(round(dt_plan / m.opt.timestep))      # control sub-ticks per plan tick
    T = len(Q)
    log = dict(t=[], qerr=[], tau_dem=[], tau_app=[], qacc=[], qddot_ref=[])
    M = np.zeros((m.nv, m.nv))
    for k in range(T):
        qd, vd, ad = Q[k], V[k], A[k]
        for _ in range(nsub):
            mujoco.mj_fullM(m, M, d.qM)
            bias = d.qfrc_bias[:7].copy()             # C(q,qd)qd + g(q)
            e = qd - d.qpos[:7]; edot = vd - d.qvel[:7]
            # computed torque + Coulomb-friction feedforward (smooth sign to avoid
            # chatter near zero velocity) to cancel the model's dry friction
            tau_dem = (M[:7, :7] @ ad + bias + KP * e + KD * edot
                       + Fc * np.tanh(d.qvel[:7] / 0.02))
            tau_app = np.clip(tau_dem, -TAU_MAX, TAU_MAX) if clip else tau_dem
            d.ctrl[:7] = tau_app
            mujoco.mj_step(m, d)
            log["t"].append(d.time)
            log["qerr"].append((qd - d.qpos[:7]).copy())
            log["tau_dem"].append(tau_dem.copy())
            log["tau_app"].append(tau_app.copy())
            log["qacc"].append(d.qacc[:7].copy())
            log["qddot_ref"].append(ad.copy())
    for key in log:
        log[key] = np.array(log[key])
    # torque rate (jerkiness of the command) per step
    dt = m.opt.timestep
    log["tau_rate"] = np.vstack([np.zeros(7), np.diff(log["tau_dem"], axis=0) / dt])
    return log


def summarize(name, log):
    tau_dem = log["tau_dem"]; qerr = log["qerr"]
    sat = int((np.abs(tau_dem) > TAU_MAX + 1e-6).sum())
    trate = np.sqrt((log["tau_rate"] ** 2).mean())
    print(f"{name:<10}{np.abs(tau_dem).max():>12.1f}{sat:>16}"
          f"{trate:>16.0f}{1e3*np.sqrt((qerr**2).mean()):>14.3f}"
          f"{1e3*np.abs(qerr).max():>14.3f}")


def main():
    n = 7
    W = WAYPOINTS
    vmax = FR3_VMAX[:n]
    di = plan_di(W, dt=0.01, vmax=vmax, amax=AMAX_PLAN)
    tg = plan_totg(W, dt=0.01, vmax=vmax, amax=AMAX_PLAN, max_dev=0.05)
    # apply each reference WITHOUT clipping so the true demanded torque is visible
    log_di = track(di, clip=False); log_tg = track(tg, clip=False)

    print("FR3 computed-torque execution (B2 acute corner; feasible planning accel)")
    print(f"{'planner':<10}{'peak|tau|':>12}{'>limit samples':>16}"
          f"{'tau-rate RMS':>16}{'RMSE[mrad]':>14}{'maxerr[mrad]':>14}")
    summarize("DI-QP", log_di); summarize("TOTG", log_tg)
    print(f"(FR3 torque limits: {TAU_MAX.tolist()} Nm)")

    try:
        import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
        j = 1                                          # stressed joint (tight torque limit nearby)
        fig, ax = plt.subplots(2, 2, figsize=(12, 7))
        ax[0, 0].plot(di["t"], di["A"][:, j], 'b', label='DI-QP')
        ax[0, 0].plot(tg["t"], tg["A"][:, j], 'r', label='TOTG')
        ax[0, 0].axhline(AMAX_PLAN[j], ls='--', c='k', lw=.7); ax[0,0].axhline(-AMAX_PLAN[j], ls='--', c='k', lw=.7)
        ax[0, 0].set_title(f"reference accel q_ddot_ref, joint {j}"); ax[0,0].set_ylabel("rad/s^2"); ax[0,0].legend()
        ax[0, 1].plot(log_di["t"], log_di["tau_dem"][:, j], 'b', label='DI-QP')
        ax[0, 1].plot(log_tg["t"], log_tg["tau_dem"][:, j], 'r', label='TOTG')
        ax[0, 1].axhline(TAU_MAX[j], ls='--', c='k', lw=.8); ax[0,1].axhline(-TAU_MAX[j], ls='--', c='k', lw=.8)
        ax[0, 1].set_title(f"demanded torque, joint {j} (dashed = limit)"); ax[0,1].set_ylabel("Nm"); ax[0,1].legend()
        rms_di = 1e3 * np.sqrt((log_di["qerr"] ** 2).mean(axis=1))
        rms_tg = 1e3 * np.sqrt((log_tg["qerr"] ** 2).mean(axis=1))
        ax[1, 0].plot(log_di["t"], rms_di, 'b', label=f'DI-QP (mean {rms_di.mean():.1f})')
        ax[1, 0].plot(log_tg["t"], rms_tg, 'r', label=f'TOTG (mean {rms_tg.mean():.1f})')
        ax[1, 0].set_title("tracking error, RMS over joints"); ax[1,0].set_xlabel("t[s]")
        ax[1,0].set_ylabel("RMSE [mrad]"); ax[1,0].set_ylim(bottom=0); ax[1,0].legend()
        # peak |tau| per joint, both planners
        x = np.arange(7); w = 0.35
        ax[1, 1].bar(x-w/2, np.abs(log_di["tau_dem"]).max(0), w, color='b', label='DI-QP')
        ax[1, 1].bar(x+w/2, np.abs(log_tg["tau_dem"]).max(0), w, color='r', label='TOTG')
        ax[1, 1].plot(x, TAU_MAX, 'k_', ms=14, label='torque limit')
        ax[1, 1].set_title("peak demanded torque per joint"); ax[1,1].set_xlabel("joint"); ax[1,1].set_ylabel("Nm"); ax[1,1].legend()
        out = RESULTS_DIR / "mujoco_compare.png"
        fig.tight_layout(); fig.savefig(out, dpi=110)
        print(f"\nsaved {out}")
    except Exception as e:
        print(f"(plot skipped: {e})")


if __name__ == "__main__":
    main()
