"""
Path-first time-optimal trajectory generation (TOTG / TOPP family) reference.

This is the classical pipeline the double-integrator planner is compared against:

  waypoints --> geometric path q(s) with circular blends (Kunz-Stilman geometry)
            --> arc-length parameterization s in [0, L]
            --> time-optimal s(t) by numerical-integration TOPP
                (forward/backward sweep on x = s_dot^2; Bobrow/Slotine/Pham)
            --> s(t) inversion + differentiation to recover q(t), q_dot, q_ddot.

The two coordinate conversions are the whole point:

  * t -> s : limits |q_dot|<=vmax, |q_ddot|<=amax are cheap *in s* (box on s_dot,
             s_ddot along a fixed path) but must be re-derived if the path moves.
  * s -> t : q_ddot = q'(s) s_ddot + q''(s) s_dot^2.  q''(s) JUMPS at every blend
             seam (curvature 0 on a straight, 1/r on an arc) -> q_ddot is
             discontinuous.  And t(s) = int ds/s_dot is SINGULAR wherever s_dot->0
             (rest points, tight blends), so recovering a uniform-time sample is
             ill-conditioned exactly there.

These are the numerical-stability failures the time-first DI planner avoids.

Not a production TOTG (no exhaustive switch-point search); it is the standard
numerical-integration TOPP core, which is sufficient to expose the conversions.
"""

import numpy as np
import time
from scipy.interpolate import CubicSpline

EPS = 1e-9


# ---------------------------------------------------------------------------
# C^2 smooth path (cubic spline) -- the "fixable artifacts" demonstration
# ---------------------------------------------------------------------------
class SmoothPath:
    """C^2 cubic-spline path through the waypoints (chord-length parameter u).

    Same eval(u) -> (q, q'(u), q''(u)) interface as BlendPath, but q''(u) is
    *continuous* (a cubic spline is C^2), so the reconstructed acceleration /
    steering has no seam discontinuity.  TOPP runs on any monotonic parameter, so
    the same topp()/resample machinery applies (q' is not unit here -- the MVC and
    accel formulas are general).  This shows limitations (a)/(b) are artifacts of
    the cheap circular blend, not of the path-first paradigm itself.
    """

    def __init__(self, waypoints):
        W = np.asarray(waypoints, float)
        self.n = W.shape[1]
        d = np.linalg.norm(np.diff(W, axis=0), axis=1)
        u = np.concatenate([[0.0], np.cumsum(np.maximum(d, EPS))])
        self.L = float(u[-1])
        self.cs = CubicSpline(u, W, bc_type="natural")   # C^2, zero end curvature
        self.cs1 = self.cs.derivative(1)
        self.cs2 = self.cs.derivative(2)
        uu = np.linspace(0, self.L, 1000)
        qp, qpp = self.cs1(uu), self.cs2(uu)
        sp = np.linalg.norm(qp, axis=1)
        cross = np.sqrt(np.maximum(
            (qpp ** 2).sum(1) * (qp ** 2).sum(1) - (qp * qpp).sum(1) ** 2, 0.0))
        kappa = cross / np.maximum(sp ** 3, EPS)
        self.min_blend_r = float(1.0 / max(kappa.max(), EPS))

    def eval(self, s):
        s = float(np.clip(s, 0.0, self.L))
        return self.cs(s), self.cs1(s), self.cs2(s)


# ---------------------------------------------------------------------------
# Geometric path with circular blends
# ---------------------------------------------------------------------------
class BlendPath:
    """Piecewise line + circular-arc path through waypoints, arc-length param.

    eval(s) -> (q, qp, qpp) with qp the *unit* tangent (|qp|=1) and qpp the
    curvature vector (|qpp| = 0 on lines, 1/r on arcs -> discontinuous at seams).
    """

    def __init__(self, waypoints, max_dev=0.1, ell_frac=0.5):
        W = np.asarray(waypoints, float)
        self.n = W.shape[1]
        segs = []           # each: dict(type, s0, length, ...)
        s_acc = 0.0
        cursor = W[0].copy()  # current free end of the path
        self.min_blend_r = np.inf

        for i in range(1, len(W) - 1):
            u1 = W[i] - W[i - 1]; L1 = np.linalg.norm(u1)
            u2 = W[i + 1] - W[i]; L2 = np.linalg.norm(u2)
            if L1 < EPS or L2 < EPS:
                continue
            u1 /= L1; u2 /= L2
            cphi = float(np.clip(u1 @ u2, -1.0, 1.0))
            phi = np.arccos(cphi)                       # turn angle
            if phi < 1e-4:                              # ~collinear: no blend
                continue
            half = phi / 2.0
            sec = 1.0 / np.cos(half)
            r = max_dev / (sec - 1.0)                   # radius from deviation
            ell = r * np.tan(half)
            ell_cap = ell_frac * min(L1, L2)
            if ell > ell_cap:                           # cap to fit the legs
                ell = ell_cap
                r = ell / np.tan(half)
            self.min_blend_r = min(self.min_blend_r, r)

            Ps = W[i] - ell * u1
            Pe = W[i] + ell * u2

            # straight from cursor -> Ps
            seg_len = np.linalg.norm(Ps - cursor)
            if seg_len > EPS:
                d = (Ps - cursor) / seg_len
                segs.append(dict(type="line", s0=s_acc, length=seg_len,
                                 P0=cursor.copy(), dir=d))
                s_acc += seg_len

            # arc Ps -> Pe (central angle = phi)
            C = self._arc_center(W[i], u1, u2, r, sec)
            e1 = (Ps - C); e1 /= np.linalg.norm(e1)
            w = (Pe - C) - ((Pe - C) @ e1) * e1
            e2 = w / np.linalg.norm(w)
            arc_len = r * phi
            segs.append(dict(type="arc", s0=s_acc, length=arc_len,
                             C=C, e1=e1, e2=e2, r=r))
            s_acc += arc_len
            cursor = Pe.copy()

        # final straight cursor -> W[-1]
        seg_len = np.linalg.norm(W[-1] - cursor)
        if seg_len > EPS:
            d = (W[-1] - cursor) / seg_len
            segs.append(dict(type="line", s0=s_acc, length=seg_len,
                             P0=cursor.copy(), dir=d))
            s_acc += seg_len

        self.segs = segs
        self.L = s_acc

    @staticmethod
    def _arc_center(Wc, u1, u2, r, sec):
        bis = u2 - u1
        bis /= np.linalg.norm(bis)
        return Wc + r * sec * bis

    def _find(self, s):
        s = float(np.clip(s, 0.0, self.L))
        lo, hi = 0, len(self.segs) - 1
        while lo < hi:
            mid = (lo + hi + 1) // 2
            if self.segs[mid]["s0"] <= s:
                lo = mid
            else:
                hi = mid - 1
        return self.segs[lo]

    def eval(self, s):
        seg = self._find(s)
        ds = float(np.clip(s, 0.0, self.L)) - seg["s0"]
        if seg["type"] == "line":
            q = seg["P0"] + ds * seg["dir"]
            return q, seg["dir"].copy(), np.zeros(self.n)
        r = seg["r"]; a = ds / r
        e1, e2, C = seg["e1"], seg["e2"], seg["C"]
        ca, sa = np.cos(a), np.sin(a)
        q = C + r * (ca * e1 + sa * e2)
        qp = -sa * e1 + ca * e2                  # unit tangent
        qpp = (-ca * e1 - sa * e2) / r           # curvature vector, |.|=1/r
        return q, qp, qpp


# ---------------------------------------------------------------------------
# Numerical-integration TOPP on x = s_dot^2
# ---------------------------------------------------------------------------
def _u_interval(qp, qpp, x, vmax, amax):
    """Feasible s_ddot interval [L,U] from accel limits at (s,x); ok flag."""
    L, U = -np.inf, np.inf
    ok = True
    for j in range(len(qp)):
        a, b = qp[j], qpp[j]
        if abs(a) < 1e-7:
            if abs(b) * x > amax[j] + 1e-9:      # zero-inertia: bound on x only
                ok = False
            continue
        lo = (-amax[j] - b * x) / a
        hi = (amax[j] - b * x) / a
        if a < 0:
            lo, hi = hi, lo
        L = max(L, lo); U = min(U, hi)
    return L, U, (ok and L <= U + 1e-9)


def topp(path, vmax, amax, K=1500):
    """Forward/backward TOPP. Returns dict with s grid, x=s_dot^2, timing."""
    vmax = np.asarray(vmax, float); amax = np.asarray(amax, float)
    s = np.linspace(0.0, path.L, K)
    ds = s[1] - s[0]
    QP = np.zeros((K, path.n)); QPP = np.zeros((K, path.n))
    for k in range(K):
        _, qp, qpp = path.eval(s[k])
        QP[k] = qp; QPP[k] = qpp

    # Max-velocity curve: velocity limits + accel feasibility (bisection).
    x_vel = np.full(K, np.inf)
    for k in range(K):
        for j in range(path.n):
            if abs(QP[k, j]) > 1e-7:
                x_vel[k] = min(x_vel[k], (vmax[j] / abs(QP[k, j])) ** 2)
    MVC = x_vel.copy()
    for k in range(K):
        hi = x_vel[k] if np.isfinite(x_vel[k]) else 1e6
        _, _, ok = _u_interval(QP[k], QPP[k], hi, vmax, amax)
        if ok:
            MVC[k] = hi
            continue
        lo = 0.0
        for _ in range(40):                       # bisection on accel feasibility
            mid = 0.5 * (lo + hi)
            _, _, ok = _u_interval(QP[k], QPP[k], mid, vmax, amax)
            if ok:
                lo = mid
            else:
                hi = mid
        MVC[k] = lo

    t0 = time.perf_counter()
    # Forward sweep (max acceleration), start from rest.
    xf = np.zeros(K)
    for k in range(K - 1):
        xk = min(xf[k], MVC[k])
        _, U, ok = _u_interval(QP[k], QPP[k], xk, vmax, amax)
        if not ok:
            U = 0.0
        xf[k + 1] = min(xk + 2.0 * U * ds, MVC[k + 1])
        xf[k + 1] = max(xf[k + 1], 0.0)
    # Backward sweep (max deceleration), end at rest.
    xb = np.zeros(K)
    for k in range(K - 1, 0, -1):
        xk = min(xb[k], MVC[k])
        L, _, ok = _u_interval(QP[k], QPP[k], xk, vmax, amax)
        if not ok:
            L = 0.0
        xb[k - 1] = min(xk - 2.0 * L * ds, MVC[k - 1])
        xb[k - 1] = max(xb[k - 1], 0.0)
    x = np.minimum(np.minimum(xf, xb), MVC)
    x = np.maximum(x, 0.0)
    build_t = time.perf_counter() - t0

    return dict(s=s, ds=ds, x=x, MVC=MVC, QP=QP, QPP=QPP, build_t=build_t)


def topp_ra(path, vmax, amax, K=1000, M=300):
    """Reachability-based TOPP (TOPP-RA core, Pham 2018 [7]): backward controllable
    sets + forward pass.  More robust at dynamic singularities than the greedy
    forward/backward sweep of topp().  Same return dict.

    Controllable set at stage i = [0, xbar_i], the largest x_i = s_dot^2 from which
    the rest-at-end goal is still reachable under the accel limits.
    """
    vmax = np.asarray(vmax, float); amax = np.asarray(amax, float)
    s = np.linspace(0.0, path.L, K); ds = s[1] - s[0]
    QP = np.zeros((K, path.n)); QPP = np.zeros((K, path.n))
    for k in range(K):
        _, qp, qpp = path.eval(s[k]); QP[k] = qp; QPP[k] = qpp

    # velocity + accel-feasibility MVC (same as topp)
    x_vel = np.full(K, np.inf)
    for k in range(K):
        for j in range(path.n):
            if abs(QP[k, j]) > 1e-7:
                x_vel[k] = min(x_vel[k], (vmax[j] / abs(QP[k, j])) ** 2)
    MVC = x_vel.copy()
    for k in range(K):
        hi = x_vel[k] if np.isfinite(x_vel[k]) else 1e6
        _, _, ok = _u_interval(QP[k], QPP[k], hi, vmax, amax)
        if not ok:
            lo = 0.0
            for _ in range(40):
                mid = 0.5 * (lo + hi)
                _, _, ok2 = _u_interval(QP[k], QPP[k], mid, vmax, amax)
                lo, hi = (mid, hi) if ok2 else (lo, mid)
            MVC[k] = lo
        else:
            MVC[k] = hi

    t0 = time.perf_counter()
    # backward controllable sets: xbar[k] = max x reachable-to-rest at the end
    xbar = np.zeros(K); xbar[K - 1] = 0.0
    for k in range(K - 2, -1, -1):
        cand = np.linspace(0.0, MVC[k], M)
        best = 0.0
        for xc in cand:
            Lk, Uk, ok = _u_interval(QP[k], QPP[k], xc, vmax, amax)
            if not ok:
                continue
            # min next-state via max deceleration must stay within next controllable set
            if xc + 2.0 * Lk * ds <= xbar[k + 1] + 1e-12:
                best = xc                       # cand is increasing -> keep largest
        xbar[k] = best
    # forward pass: greedily max accel, clipped to the controllable set
    x = np.zeros(K)
    for k in range(K - 1):
        Lk, Uk, ok = _u_interval(QP[k], QPP[k], x[k], vmax, amax)
        if not ok:
            Uk = 0.0
        x[k + 1] = min(x[k] + 2.0 * Uk * ds, xbar[k + 1], MVC[k + 1])
        x[k + 1] = max(x[k + 1], 0.0)
    build_t = time.perf_counter() - t0
    return dict(s=s, ds=ds, x=x, MVC=MVC, xbar=xbar, QP=QP, QPP=QPP, build_t=build_t)


def plan_totg(waypoints, dt=0.01, vmax=None, amax=None, max_dev=0.1, K=1000,
              smooth=False, method="ni"):
    """Full path-first pipeline; output sampled at uniform dt to match DI planner.

    smooth=False : circular-blend path (the standard TOTG core).
    smooth=True  : C^2 cubic-spline path (overcomes the seam-discontinuity, (a)/(b)).
    method="ni"  : numerical-integration TOPP (forward/backward sweep).
    method="ra"  : reachability-based TOPP-RA (controllable sets) [7].
    """
    from di_planner import FR3_VMAX, FR3_AMAX
    waypoints = np.asarray(waypoints, float)
    n = waypoints.shape[1]
    if vmax is None: vmax = FR3_VMAX[:n]
    if amax is None: amax = FR3_AMAX[:n]

    t_path0 = time.perf_counter()
    path = SmoothPath(waypoints) if smooth else BlendPath(waypoints, max_dev=max_dev)
    res = topp_ra(path, vmax, amax, K=K) if method == "ra" else topp(path, vmax, amax, K=K)
    s, ds, x = res["s"], res["ds"], res["x"]
    sdot = np.sqrt(np.maximum(x, 0.0))

    # s -> t : t(s) = int ds / s_dot.  Use the constant-accel interval form
    #   dt_k = 2 ds / (s_dot_k + s_dot_{k+1}),  exact per interval and finite when
    # s_dot = 0 at one end (rest / tight blend); it is still ILL-CONDITIONED where
    # s_dot -> 0 (the 1/s_dot blow-up), which is what max_inv_sdot reports.
    denom = sdot[1:] + sdot[:-1]
    dt_seg = 2.0 * ds / np.maximum(denom, 1e-9)
    t_of_s = np.concatenate([[0.0], np.cumsum(dt_seg)])
    T = t_of_s[-1]
    build_t = res["build_t"] + (time.perf_counter() - t_path0 - res["build_t"])

    # s_ddot(s) = 0.5 d(x)/ds  (the chosen path acceleration).
    sdd = 0.5 * np.gradient(x, s)

    # Singularity guard: if s_dot collapses (tight near-reversal blend, true cusp)
    # the s->t map blows up -- T -> very large and the uniform-time sample would be
    # unbounded.  This is the s->t conversion FAILING, not a feature; report it.
    interior_sdot = sdot[1:-1]
    min_sdot_int = float(interior_sdot.min()) if interior_sdot.size else 0.0
    NT_CAP = 200000
    stalled = (not np.isfinite(T)) or (T / dt > NT_CAP) or (min_sdot_int < 1e-3)

    # Sample at uniform time: invert t(s) (the second conversion).
    nT = max(min(int(np.ceil(T / dt)) + 1, NT_CAP), 2)
    tt = np.linspace(0.0, T, nT)
    ss = np.interp(tt, t_of_s, s)
    Q = np.zeros((nT, n)); V = np.zeros((nT, n)); A = np.zeros((nT, n))
    sdot_i = np.interp(ss, s, sdot)
    sdd_i = np.interp(ss, s, sdd)
    for k in range(nT):
        q, qp, qpp = path.eval(ss[k])
        Q[k] = q
        V[k] = qp * sdot_i[k]
        A[k] = qp * sdd_i[k] + qpp * (sdot_i[k] ** 2)   # q'' jump -> A jump

    return dict(
        Q=Q, V=V, A=A, dt=dt, t=tt, T=T,
        build_t=build_t, path_len=path.L,
        min_blend_r=path.min_blend_r,
        min_sdot=min_sdot_int,
        max_inv_sdot=float(1.0 / min_sdot_int) if min_sdot_int > 1e-12 else np.inf,
        stalled=stalled,
        sdot_curve=sdot, s_grid=s,
    )


if __name__ == "__main__":
    from di_planner import FR3_VMAX, FR3_AMAX
    wps = np.array([
        [0.0, 0.0, 0.0],
        [1.0, -0.5, 0.3],
        [1.5, 0.4, -0.4],
    ])
    r = plan_totg(wps, dt=0.01, vmax=FR3_VMAX[:3], amax=FR3_AMAX[:3], max_dev=0.1)
    print(f"path length L = {r['path_len']:.3f}  min blend r = {r['min_blend_r']:.3f}")
    print(f"time-optimal T = {r['T']:.3f}s  samples = {len(r['t'])}")
    print(f"peak |v| = {np.abs(r['V']).max(0)}  (limit {FR3_VMAX[:3]})")
    print(f"peak |a| = {np.abs(r['A']).max(0)}  (limit {FR3_AMAX[:3]})")
    vviol = (np.abs(r['V']) > FR3_VMAX[:3] + 1e-3).sum()
    aviol = (np.abs(r['A']) > FR3_AMAX[:3] + 1e-3).sum()
    print(f"vel violations = {vviol}  acc violations = {aviol}")
    print(f"min s_dot (interior) = {r['min_sdot']:.4f}  -> max 1/s_dot = "
          f"{1.0/max(r['min_sdot'],1e-12):.1f}")
    print(f"build time = {1e3*r['build_t']:.2f} ms")
    print(f"final q = {r['Q'][-1]}  (goal {wps[-1]})")
