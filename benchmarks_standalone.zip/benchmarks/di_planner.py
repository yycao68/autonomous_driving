"""
Double-Integrator receding-horizon QP motion planner (Layer 2).

Time-first planning: each joint is a virtual double integrator with a *constant*
state-transition matrix A_d.  The acceleration u = q_ddot is the decision
variable, kinematic limits are box constraints in the time domain, and waypoints
are supplied directly as inputs.  No path / arc-length (s) variable ever appears,
so there is no t->s or s->t conversion (contrast: di_totg.py).

The planner is decoupled per joint (the paper's constant-A_d claim): we solve n
small QPs of size N each control cycle and warm-start OSQP across cycles.

Reference: motion_planning_double_integrator.md, Sections II-III.
"""

import numpy as np
import scipy.sparse as sp
import osqp
import time


# ---------------------------------------------------------------------------
# FR3 (Franka Research 3) kinematic limits
# ---------------------------------------------------------------------------
# Joint velocity limits [rad/s] and a conservative acceleration set [rad/s^2].
FR3_VMAX = np.array([2.62, 2.62, 2.62, 2.62, 5.26, 4.18, 5.26])
FR3_AMAX = np.array([15.0, 7.5, 10.0, 12.5, 15.0, 20.0, 20.0])
FR3_QMIN = np.array([-2.74, -1.78, -2.90, -3.04, -2.81, 0.54, -3.02])
FR3_QMAX = np.array([2.74, 1.78, 2.90, -0.15, 2.81, 4.52, 3.02])


def di_matrices(dt, N):
    """Prediction matrices for one scalar double integrator over horizon N.

    State x=[q, v].  Returns Phi_p,(N,2) Phi_v,(N,2) Gam_p,(N,N) Gam_v,(N,N)
    such that  pos = Phi_p @ x0 + Gam_p @ U,  vel = Phi_v @ x0 + Gam_v @ U,
    where U=[u_0..u_{N-1}] are the per-step accelerations.

    Because A_c is nilpotent these are exact and *constant* (precomputed once).
    """
    k = np.arange(1, N + 1)
    Phi_p = np.column_stack([np.ones(N), k * dt])      # q_k = q0 + k dt v0
    Phi_v = np.column_stack([np.zeros(N), np.ones(N)])  # v_k = v0
    Gam_p = np.zeros((N, N))
    Gam_v = np.zeros((N, N))
    for kk in range(1, N + 1):
        for j in range(kk):
            m = kk - 1 - j
            Gam_p[kk - 1, j] = dt * dt * (m + 0.5)
            Gam_v[kk - 1, j] = dt
    return Phi_p, Phi_v, Gam_p, Gam_v


class JointQP:
    """Per-joint receding-horizon QP, set up once and updated each cycle."""

    def __init__(self, dt, N, vmax, amax, wq, wv, wr, gamma, qmin=None, qmax=None):
        self.dt, self.N = dt, N
        self.vmax, self.amax = vmax, amax
        self.Phi_p, self.Phi_v, self.Gam_p, self.Gam_v = di_matrices(dt, N)

        # Stage weights with a terminal multiplier gamma on the last step.
        Wq = np.full(N, wq); Wq[-1] *= gamma
        Wv = np.full(N, wv); Wv[-1] *= gamma
        self.Wq, self.Wv, self.wr = Wq, Wv, wr

        # Constant Hessian H = Gp' Wq Gp + Gv' Wv Gv + wr I  (>0, strictly convex).
        H = (self.Gam_p.T @ (Wq[:, None] * self.Gam_p)
             + self.Gam_v.T @ (Wv[:, None] * self.Gam_v)
             + wr * np.eye(N))
        H = 0.5 * (H + H.T)
        self.P = sp.csc_matrix(H)

        # Constraints: velocity rows (Gam_v) + acceleration box (I).
        # Optional position rows (Gam_p) appended when qmin/qmax given.
        rows = [self.Gam_v, np.eye(N)]
        self.has_pos = qmin is not None and qmax is not None
        if self.has_pos:
            rows.append(self.Gam_p)
        A = sp.csc_matrix(np.vstack(rows))
        self.A = A
        self.qmin, self.qmax = qmin, qmax

        # Placeholder l/u (filled per cycle in update()).
        nrows = A.shape[0]
        l0 = -np.inf * np.ones(nrows)
        u0 = np.inf * np.ones(nrows)
        self.prob = osqp.OSQP()
        self.prob.setup(self.P, np.zeros(N), self.A, l0, u0,
                        verbose=False, warm_starting=True,
                        eps_abs=1e-6, eps_rel=1e-6, max_iter=4000)

    def solve(self, x0, q_goal, v_goal):
        """One cycle: returns full optimal U, solve time, and success flag."""
        Phi_p, Phi_v, Gam_v = self.Phi_p, self.Phi_v, self.Gam_v
        # Linear term q = Gp' Wq (Phi_p x0 - qg) + Gv' Wv (Phi_v x0 - vg)
        ep = Phi_p @ x0 - q_goal
        ev = Phi_v @ x0 - v_goal
        q = (self.Gam_p.T @ (self.Wq * ep) + Gam_v.T @ (self.Wv * ev))

        # Bounds.  Velocity: -vmax-Phi_v x0 <= Gam_v U <= vmax-Phi_v x0.
        v_free = Phi_v @ x0
        lv = -self.vmax - v_free
        uv = self.vmax - v_free
        la = -self.amax * np.ones(self.N)
        ua = self.amax * np.ones(self.N)
        l = [lv, la]; u = [uv, ua]
        if self.has_pos:
            p_free = Phi_p @ x0
            l.append(self.qmin - p_free)
            u.append(self.qmax - p_free)
        l = np.concatenate(l); u = np.concatenate(u)

        self.prob.update(q=q, l=l, u=u)
        res = self.prob.solve()
        if res.info.status_val not in (1, 2):  # solved / solved inaccurate
            return np.zeros(self.N), res.info.solve_time, False
        return res.x, res.info.solve_time, True


def plan_di(waypoints, dt=0.01, N=20, vmax=None, amax=None,
            wq=50.0, wv=0.0, wr=0.05, gamma=8.0,
            switch_radius=0.08, v_pass=0.5, use_qlim=False,
            t_max=20.0, v0=None, final_stop=True, velocity_law=False):
    """Run the DI-QP planner through a sequence of waypoints.

    waypoints : (M, n) array, first row is the start configuration.
    Returns dict with time series Q,V,A (T, n) and per-cycle solve times.

    Intermediate waypoints are *passed through* (terminal velocity weight wv=0,
    a pass-through velocity target along the next leg); only the final waypoint
    requests a full stop (v_goal=0).
    """
    waypoints = np.asarray(waypoints, float)
    M, n = waypoints.shape
    if vmax is None: vmax = FR3_VMAX[:n]
    if amax is None: amax = FR3_AMAX[:n]

    qmin = FR3_QMIN[:n] if use_qlim else None
    qmax = FR3_QMAX[:n] if use_qlim else None

    qps = [JointQP(dt, N, vmax[i], amax[i], wq, wv, wr, gamma,
                   None if not use_qlim else qmin[i],
                   None if not use_qlim else qmax[i]) for i in range(n)]

    x = np.zeros((n, 2)); x[:, 0] = waypoints[0]
    if v0 is not None:
        x[:, 1] = v0
    Q, V, A, solve_t = [], [], [], []
    solver_failures = 0
    target = 1
    steps = int(t_max / dt)
    for _ in range(steps):
        last = (target == M - 1)
        goal = waypoints[target]
        v_ref = None  # per-step (N,n) reference when velocity_law is on
        if velocity_law:
            # Build the time-optimal double-integrator velocity reference over the
            # whole horizon by rolling the braking law forward from the current
            # state:  v_des = sign(dq) * min(vmax, sqrt(2 amax |dq|)) brakes to 0
            # at the final waypoint; intermediate waypoints cruise at vmax along
            # the outgoing leg.  Feeding it per-step (not as one constant) avoids
            # the limit-cycle of a fixed target; the QP still enforces hard limits.
            v_ref = np.zeros((N, n))
            qpred = x[:, 0].copy()
            for k in range(N):
                dq = goal - qpred
                if last:   # brake to 0 at the final waypoint (time-optimal law)
                    vdes = np.clip(np.sign(dq) * np.sqrt(2.0 * amax * np.abs(dq)),
                                   -vmax, vmax)
                else:      # cruise at full speed toward the current waypoint
                    vdes = np.sign(dq) * vmax
                v_ref[k] = vdes
                qpred = qpred + vdes * dt
            stop_here = False
        elif last and final_stop:
            v_goal = np.zeros(n); stop_here = True
        elif last:  # cruise through the final waypoint along the last leg
            leg = waypoints[target] - waypoints[target - 1]
            nrm = np.linalg.norm(leg)
            v_goal = (v_pass * vmax * leg / nrm) if nrm > 1e-9 else np.zeros(n)
            stop_here = False
        else:
            leg = waypoints[target + 1] - waypoints[target]
            nrm = np.linalg.norm(leg)
            v_goal = (v_pass * vmax * leg / nrm) if nrm > 1e-9 else np.zeros(n)
            stop_here = False

        u0 = np.zeros(n); st = 0.0
        for i in range(n):
            vg_i = v_ref[:, i] if velocity_law else (0.0 if stop_here else v_goal[i])
            U, t_solve, ok = qps[i].solve(x[i], goal[i], vg_i)
            solver_failures += 0 if ok else 1
            u0[i] = U[0]; st = max(st, t_solve)
        # Apply first acceleration, exact double-integrator step.
        for i in range(n):
            q0, v0 = x[i]
            x[i, 0] = q0 + dt * v0 + 0.5 * dt * dt * u0[i]
            x[i, 1] = v0 + dt * u0[i]
        Q.append(x[:, 0].copy()); V.append(x[:, 1].copy()); A.append(u0.copy())
        solve_t.append(st)

        # Waypoint switching by proximity.
        if np.linalg.norm(x[:, 0] - waypoints[target]) < switch_radius:
            if last:
                if (not final_stop) or np.linalg.norm(x[:, 1]) < 0.02:
                    break
            else:
                target += 1

    Q_arr, V_arr, A_arr = np.array(Q), np.array(V), np.array(A)
    final_dist = np.linalg.norm(Q_arr[-1] - waypoints[-1]) if len(Q_arr) else np.inf
    final_speed = np.linalg.norm(V_arr[-1]) if len(V_arr) else np.inf
    reached = final_dist < switch_radius and ((not final_stop) or final_speed < 0.02)
    return {
        "Q": Q_arr, "V": V_arr, "A": A_arr,
        "dt": dt, "t": np.arange(len(Q_arr)) * dt,
        "solve_t": np.array(solve_t), "reached": reached,
        "final_dist": final_dist, "final_speed": final_speed,
        "solver_failures": solver_failures,
    }


if __name__ == "__main__":
    # Self-test: 3-waypoint path in joint space.
    wps = np.array([
        [0.0, 0.0, 0.0],
        [1.0, -0.5, 0.3],
        [1.5, 0.4, -0.4],
    ])
    res = plan_di(wps, dt=0.01, N=20, vmax=FR3_VMAX[:3], amax=FR3_AMAX[:3])
    T = res["t"][-1]
    print(f"reached={res['reached']}  T={T:.3f}s  steps={len(res['t'])}")
    print(f"peak |v| = {np.abs(res['V']).max(0)}  (limit {FR3_VMAX[:3]})")
    print(f"peak |a| = {np.abs(res['A']).max(0)}  (limit {FR3_AMAX[:3]})")
    vviol = (np.abs(res['V']) > FR3_VMAX[:3] + 1e-3).sum()
    aviol = (np.abs(res['A']) > FR3_AMAX[:3] + 1e-3).sum()
    print(f"vel violations={vviol}  acc violations={aviol}")
    print(f"mean QP solve = {1e3*res['solve_t'].mean():.3f} ms  "
          f"max = {1e3*res['solve_t'].max():.3f} ms")
    print(f"final q = {res['Q'][-1]}  (goal {wps[-1]})")
