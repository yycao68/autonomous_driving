"""Resolve limitation 1: narrow the DI time-optimality gap with the velocity law.

Compares, on B1/B2/B4:  baseline DI (position cost)  vs  velocity-law DI  vs  TOTG.
Reports time-to-goal, accel violations (must be 0), and jerk RMS.
"""
import numpy as np
from di_planner import plan_di, FR3_VMAX, FR3_AMAX
from di_totg import plan_totg
from benchmark_fr3 import metrics, b1_point_to_point, b2_acute_corner, b4_dense_noisy

SCN = [("B1", b1_point_to_point(), 0.1),
       ("B2", b2_acute_corner(0.05), 0.05),
       ("B4", b4_dense_noisy(), 0.08)]

# velocity-law weights: velocity tracking dominant, position keeps it on target
VL = dict(N=20, wq=8.0, wv=25.0, wr=0.02, gamma=8.0, velocity_law=True,
          switch_radius=0.12)

print(f"{'scn':>4}{'planner':>16}{'T[s]':>9}{'a-viol':>8}{'jerkRMS':>10}{'vs TOTG':>9}")
for tag, (name, W, n, kw), dev in SCN:
    vmax, amax = FR3_VMAX[:n], FR3_AMAX[:n]
    tg = plan_totg(W, dt=0.01, vmax=vmax, amax=amax, max_dev=dev)
    Ttg = tg["t"][-1]
    base = plan_di(W, dt=0.01, N=20, vmax=vmax, amax=amax)
    vl = plan_di(W, dt=0.01, vmax=vmax, amax=amax, **VL)
    for label, r in [("baseline DI", base), ("velocity-law DI", vl),
                     ("TOTG", tg)]:
        m = metrics(r, vmax, amax, 0.01)
        ratio = m["T"] / Ttg
        print(f"{tag:>4}{label:>16}{m['T']:>9.2f}{m['a_viol']:>8}"
              f"{m['jerk_rms']:>10.1f}{ratio:>8.2f}x")
    print()
