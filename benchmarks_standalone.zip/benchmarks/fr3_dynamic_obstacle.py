"""
7-DOF FR3 dynamic-obstacle test (addresses the review's top recommendation).

The arm reaches a joint-space goal while a spherical obstacle crosses the
end-effector path mid-motion.  This exercises the Section IV task-space
constraints on the real 7-DOF arm (not a planar point robot):

  * DI-QP : coupled 7-joint receding-horizon QP with HARD joint velocity/accel
    box limits + the linearized EE half-space  n^T(p_ee(k)-p_obs) >= R_safe
    (Method A), plus an APF joint-velocity deflection (Method B) as the steering
    reference and a penalized slack.
  * Baseline : resolved-rate + APF reactive controller (no hard limits) -- the
    kind of reactive scheme the QP is meant to improve on.

We report joint-limit violations, EE clearance, and per-cycle solve time, and
separately quantify the Jacobian-linearization error over the horizon vs joint
speed and horizon length N.  Plots -> fr3_dynamic.png.
"""
import time
import numpy as np
import scipy.sparse as sp
import osqp
from pathlib import Path
from di_planner import di_matrices, FR3_VMAX, FR3_AMAX
from fr3_kinematics import fk, jacobian_v

# Only autonomous_driving/paper/mp_main.tex (via the benchmarks/ shim) uses this
# script's figure; save straight into its simulationResults/ folder.
RESULTS_DIR = Path(__file__).parent.parent.parent / "autonomous_driving" / "simulationResults"

DT = 0.01
N = 20
VMAX = FR3_VMAX.copy()
AMAX = FR3_AMAX.copy()
R_OBS = 0.10
R_SAFE = 0.16          # required EE clearance (obstacle + margin)
RHO0 = 0.45            # APF influence radius (task space)
T_MAX = 4.0

Q_START = np.array([0.0, -0.4, 0.0, -1.8, 0.0, 1.4, 0.0])
Q_GOAL = np.array([1.4, 0.5, 0.2, -1.2, 0.1, 1.6, 0.3])


def obstacle_pos(t):
    """Sphere crossing the EE path: interpolate near the EE mid-path point."""
    p0 = fk(Q_START); pg = fk(Q_GOAL)
    mid = 0.5 * (p0 + pg)
    # cross vertically (z) through the mid point over the motion
    return mid + np.array([0.0, 0.0, 0.30 - 0.32 * t])


def _apf_joint_deflection(q, p_obs):
    """APF repulsive task-space force mapped to a joint velocity deflection."""
    p = fk(q); d = p - p_obs; dn = np.linalg.norm(d)
    if dn > RHO0:
        return np.zeros(7), dn
    Jv = jacobian_v(q)
    rad = d / dn
    F = 1.2 * (1.0 / dn - 1.0 / RHO0) / (dn * dn) * rad      # repulsive force
    Jpinv = np.linalg.pinv(Jv)
    return Jpinv @ F, dn


# ---------------------------------------------------------------------------
# DI-QP reactive planner (hard limits + EE half-space + APF reference)
# ---------------------------------------------------------------------------
def run_qp(rho_slack=1e5):
    Phi_p, Phi_v, Gam_p, Gam_v = di_matrices(DT, N)
    wq, wv, wr, gamma = 6.0, 8.0, 0.05, 8.0
    blocks = []
    for j in range(7):
        Wq = np.full(N, wq); Wq[-1] *= gamma
        Wv = np.full(N, wv); Wv[-1] *= gamma
        blocks.append(Gam_p.T @ (Wq[:, None] * Gam_p)
                      + Gam_v.T @ (Wv[:, None] * Gam_v) + wr * np.eye(N))
    Hjoints = sp.block_diag(blocks)
    P = sp.block_diag([Hjoints, sp.csc_matrix([[rho_slack]])]).tocsc()
    Wq = np.full(N, wq); Wq[-1] *= gamma
    Wv = np.full(N, wv); Wv[-1] *= gamma

    x = np.zeros((7, 2)); x[:, 0] = Q_START
    Q, V, A, solve_t = [], [], [], []
    solver_failures = 0
    clr = np.inf; max_slack = 0.0
    nstep = int(T_MAX / DT)
    for k in range(nstep):
        t = k * DT
        q = x[:, 0]; v = x[:, 1]
        p_ee = fk(q); p_obs = obstacle_pos(t)
        d0 = np.linalg.norm(p_ee - p_obs); clr = min(clr, d0 - R_OBS)
        nrm = (p_ee - p_obs) / max(d0, 1e-9)
        Jv = jacobian_v(q)
        nJ = nrm @ Jv                       # (7,) row: d(EE along n)/dq
        vdefl, _ = _apf_joint_deflection(q, p_obs)

        # per-joint velocity-law reference toward goal + APF deflection
        dq = Q_GOAL - q
        v_law = np.clip(np.sign(dq) * np.sqrt(2 * AMAX * np.abs(dq)), -VMAX, VMAX)
        v_ref = np.clip(v_law + 8.0 * vdefl, -VMAX, VMAX)

        # linear cost term per joint
        qlin = np.zeros(7 * N)
        for j in range(7):
            ep = Phi_p @ x[j] - Q_GOAL[j]
            ev = Phi_v @ x[j] - v_ref[j]
            qlin[j*N:(j+1)*N] = Gam_p.T @ (Wq * ep) + Gam_v.T @ (Wv * ev)
        qvec = np.concatenate([qlin, [0.0]])

        # constraints
        rows = []; lo = []; up = []
        # velocity box per joint
        for j in range(7):
            blk = np.zeros((N, 7*N + 1)); blk[:, j*N:(j+1)*N] = Gam_v
            rows.append(blk)
            vf = Phi_v @ x[j]
            lo.append(-VMAX[j] - vf); up.append(VMAX[j] - vf)
        # accel box per joint
        for j in range(7):
            blk = np.zeros((N, 7*N + 1)); blk[:, j*N:(j+1)*N] = np.eye(N)
            rows.append(blk); lo.append(-AMAX[j]*np.ones(N)); up.append(AMAX[j]*np.ones(N))
        # slack >= 0
        sblk = np.zeros((1, 7*N + 1)); sblk[0, -1] = 1.0
        rows.append(sblk); lo.append([0.0]); up.append([np.inf])
        # EE half-space at every step k': n.J Gam_p U + sigma >= R_safe - d0 - n.J*(k' dt v)
        Aobs = np.zeros((N, 7*N + 1))
        for j in range(7):
            Aobs[:, j*N:(j+1)*N] = nJ[j] * Gam_p
        Aobs[:, -1] = 1.0
        kk = np.arange(1, N + 1)
        free = np.zeros(N)
        for j in range(7):
            free += nJ[j] * (kk * DT * x[j, 1])
        rows.append(Aobs); lo.append((R_SAFE - d0) - free); up.append(np.full(N, np.inf))

        Acon = sp.csc_matrix(np.vstack(rows))
        l = np.concatenate(lo); u = np.concatenate(up)
        prob = osqp.OSQP()
        prob.setup(P, qvec, Acon, l, u, verbose=False, eps_abs=1e-6, eps_rel=1e-6,
                   max_iter=6000)
        res = prob.solve()
        solve_t.append(res.info.solve_time)
        ok = res.info.status_val in (1, 2)
        solver_failures += 0 if ok else 1
        sol = res.x if ok else np.zeros(7*N + 1)
        max_slack = max(max_slack, abs(sol[-1]))
        u0 = np.array([sol[j*N] for j in range(7)])
        for j in range(7):
            q0, v0 = x[j]
            x[j, 0] = q0 + DT*v0 + 0.5*DT*DT*u0[j]
            x[j, 1] = v0 + DT*u0[j]
        Q.append(x[:, 0].copy()); V.append(x[:, 1].copy()); A.append(u0.copy())
        if np.linalg.norm(x[:, 0] - Q_GOAL) < 0.08:
            break
    Q, V, A = np.array(Q), np.array(V), np.array(A)
    return dict(Q=Q, V=V, A=A, t=np.arange(len(Q))*DT, solve_t=np.array(solve_t),
                min_clr=clr, max_slack=max_slack,
                v_viol=int((np.abs(V) - VMAX > 1e-3).sum()),
                a_viol=int((np.abs(A) - AMAX > 1e-3).sum()),
                reached=np.linalg.norm(Q[-1]-Q_GOAL) < 0.1,
                solver_failures=solver_failures)


# ---------------------------------------------------------------------------
# Same coupled QP, but with fixed sparsity and OSQP numeric updates in-place.
# This is the implementation path the paper's constant-structure claim implies:
# the KKT sparsity is fixed, while q/l/u and obstacle-row numeric values change.
# ---------------------------------------------------------------------------
def _coupled_problem_matrices(rho_slack=1e5):
    Phi_p, Phi_v, Gam_p, Gam_v = di_matrices(DT, N)
    wq, wv, wr, gamma = 6.0, 8.0, 0.05, 8.0
    Wq = np.full(N, wq); Wq[-1] *= gamma
    Wv = np.full(N, wv); Wv[-1] *= gamma
    blocks = [
        Gam_p.T @ (Wq[:, None] * Gam_p)
        + Gam_v.T @ (Wv[:, None] * Gam_v)
        + wr * np.eye(N)
        for _ in range(7)
    ]
    Hjoints = sp.block_diag(blocks)
    P = sp.block_diag([Hjoints, sp.csc_matrix([[rho_slack]])]).tocsc()
    return Phi_p, Phi_v, Gam_p, Gam_v, Wq, Wv, P


def _fixed_constraint_matrix(Gam_p_sp, Gam_v_sp, nJ):
    nvar = 7 * N + 1
    zero = sp.csc_matrix((N, N))
    zcol = sp.csc_matrix((N, 1))
    rows = []

    for j in range(7):
        blocks = [zero] * 7 + [zcol]
        blocks[j] = Gam_v_sp
        rows.append(sp.hstack(blocks, format="csc"))

    eye = sp.eye(N, format="csc")
    for j in range(7):
        blocks = [zero] * 7 + [zcol]
        blocks[j] = eye
        rows.append(sp.hstack(blocks, format="csc"))

    slack = sp.csc_matrix(([1.0], ([0], [nvar - 1])), shape=(1, nvar))
    rows.append(slack)

    # Obstacle row has fixed lower-triangular Gamma_p sparsity in every joint
    # block.  Multiplying sparse Gamma_p by zero keeps the explicit pattern, so
    # OSQP can update Ax without rebuilding the symbolic factorization.
    obs_blocks = [Gam_p_sp * float(nJ[j]) for j in range(7)]
    obs_blocks.append(sp.csc_matrix(np.ones((N, 1))))
    rows.append(sp.hstack(obs_blocks, format="csc"))

    A = sp.vstack(rows, format="csc")
    A.sort_indices()
    return A


def run_qp_fixed_sparsity(rho_slack=1e5):
    Phi_p, Phi_v, Gam_p, Gam_v, Wq, Wv, P = _coupled_problem_matrices(rho_slack)
    Gam_p_sp = sp.csc_matrix(Gam_p)
    Gam_v_sp = sp.csc_matrix(Gam_v)
    A_template = _fixed_constraint_matrix(Gam_p_sp, Gam_v_sp, np.ones(7))

    nrows = A_template.shape[0]
    prob = osqp.OSQP()
    prob.setup(P, np.zeros(7 * N + 1), A_template,
               -np.inf * np.ones(nrows), np.inf * np.ones(nrows),
               verbose=False, warm_starting=True,
               eps_abs=1e-6, eps_rel=1e-6, max_iter=6000)

    x = np.zeros((7, 2)); x[:, 0] = Q_START
    Q, V, Aout, solve_t, cycle_t = [], [], [], [], []
    solver_failures = 0
    clr = np.inf; max_slack = 0.0
    nstep = int(T_MAX / DT)
    for k in range(nstep):
        tic = time.perf_counter()
        t = k * DT
        q = x[:, 0]
        p_ee = fk(q); p_obs = obstacle_pos(t)
        d0 = np.linalg.norm(p_ee - p_obs); clr = min(clr, d0 - R_OBS)
        nrm = (p_ee - p_obs) / max(d0, 1e-9)
        Jv = jacobian_v(q)
        nJ = nrm @ Jv
        vdefl, _ = _apf_joint_deflection(q, p_obs)

        dq = Q_GOAL - q
        v_law = np.clip(np.sign(dq) * np.sqrt(2 * AMAX * np.abs(dq)), -VMAX, VMAX)
        v_ref = np.clip(v_law + 8.0 * vdefl, -VMAX, VMAX)

        qlin = np.zeros(7 * N)
        for j in range(7):
            ep = Phi_p @ x[j] - Q_GOAL[j]
            ev = Phi_v @ x[j] - v_ref[j]
            qlin[j*N:(j+1)*N] = Gam_p.T @ (Wq * ep) + Gam_v.T @ (Wv * ev)
        qvec = np.concatenate([qlin, [0.0]])

        lo = []; up = []
        for j in range(7):
            vf = Phi_v @ x[j]
            lo.append(-VMAX[j] - vf); up.append(VMAX[j] - vf)
        for j in range(7):
            lo.append(-AMAX[j] * np.ones(N)); up.append(AMAX[j] * np.ones(N))
        lo.append([0.0]); up.append([np.inf])

        kk = np.arange(1, N + 1)
        free = np.zeros(N)
        for j in range(7):
            free += nJ[j] * (kk * DT * x[j, 1])
        lo.append((R_SAFE - d0) - free); up.append(np.full(N, np.inf))
        l = np.concatenate(lo); u = np.concatenate(up)

        Acon = _fixed_constraint_matrix(Gam_p_sp, Gam_v_sp, nJ)
        if Acon.nnz != A_template.nnz:
            raise RuntimeError("fixed-sparsity update changed A nnz")
        prob.update(q=qvec, l=l, u=u, Ax=Acon.data)
        res = prob.solve()
        solve_t.append(res.info.solve_time)
        ok = res.info.status_val in (1, 2)
        solver_failures += 0 if ok else 1
        sol = res.x if ok else np.zeros(7*N + 1)
        max_slack = max(max_slack, abs(sol[-1]))
        u0 = np.array([sol[j*N] for j in range(7)])
        for j in range(7):
            q0, v0 = x[j]
            x[j, 0] = q0 + DT*v0 + 0.5*DT*DT*u0[j]
            x[j, 1] = v0 + DT*u0[j]
        Q.append(x[:, 0].copy()); V.append(x[:, 1].copy()); Aout.append(u0.copy())
        cycle_t.append(time.perf_counter() - tic)
        if np.linalg.norm(x[:, 0] - Q_GOAL) < 0.08:
            break

    Q, V, Aout = np.array(Q), np.array(V), np.array(Aout)
    return dict(Q=Q, V=V, A=Aout, t=np.arange(len(Q))*DT,
                solve_t=np.array(solve_t), cycle_t=np.array(cycle_t),
                min_clr=clr, max_slack=max_slack,
                v_viol=int((np.abs(V) - VMAX > 1e-3).sum()),
                a_viol=int((np.abs(Aout) - AMAX > 1e-3).sum()),
                reached=np.linalg.norm(Q[-1]-Q_GOAL) < 0.1,
                solver_failures=solver_failures)


# ---------------------------------------------------------------------------
# Reactive baseline: resolved-rate + APF, no hard limits
# ---------------------------------------------------------------------------
def run_baseline():
    q = Q_START.copy(); v_prev = np.zeros(7)
    Q, V, A = [], [], []; clr = np.inf
    nstep = int(T_MAX / DT)
    for k in range(nstep):
        t = k * DT
        p_ee = fk(q); p_obs = obstacle_pos(t)
        d0 = np.linalg.norm(p_ee - p_obs); clr = min(clr, d0 - R_OBS)
        dq = Q_GOAL - q
        v_law = np.clip(np.sign(dq) * np.sqrt(2*AMAX*np.abs(dq)), -VMAX, VMAX)
        vdefl, _ = _apf_joint_deflection(q, p_obs)
        v_cmd = v_law + 8.0 * vdefl            # NO hard clamp (reactive controller)
        a = (v_cmd - v_prev) / DT
        q = q + DT * v_cmd
        Q.append(q.copy()); V.append(v_cmd.copy()); A.append(a.copy()); v_prev = v_cmd
        if np.linalg.norm(q - Q_GOAL) < 0.08:
            break
    Q, V, A = np.array(Q), np.array(V), np.array(A)
    return dict(Q=Q, V=V, A=A, t=np.arange(len(Q))*DT, min_clr=clr,
                v_viol=int((np.abs(V) - VMAX > 1e-3).sum()),
                a_viol=int((np.abs(A) - AMAX > 1e-3).sum()),
                reached=np.linalg.norm(Q[-1]-Q_GOAL) < 0.1)


# ---------------------------------------------------------------------------
# Jacobian linearization error over the horizon vs joint speed and N
# ---------------------------------------------------------------------------
def jacobian_error_study():
    rng = np.random.default_rng(0)
    print(f"\nJacobian-linearization error: true EE vs  p0 + Jv*dq  at horizon end")
    print(f"{'joint speed':>12}{'N*dt[s]':>9}{'EE error [mm]':>15}")
    q0 = Q_START.copy()
    Jv = jacobian_v(q0); p0 = fk(q0)
    for vscale in (0.25, 0.5, 1.0):
        vq = vscale * VMAX * np.sign(Q_GOAL - q0)      # constant joint velocity
        for Nh in (10, 20, 40):
            dq = Nh * DT * vq
            p_lin = p0 + Jv @ dq
            p_true = fk(q0 + dq)
            err = 1e3 * np.linalg.norm(p_true - p_lin)
            print(f"{vscale:>11.0%}{Nh*DT:>9.2f}{err:>15.2f}")


def main():
    qp = run_qp_fixed_sparsity(); bl = run_baseline()
    print("=" * 62)
    print("7-DOF FR3, spherical obstacle crossing the EE path")
    print("=" * 62)
    print(f"{'metric':<26}{'DI-QP':>16}{'reactive baseline':>20}")
    print("-" * 62)
    rows = [
        ("reached goal", str(qp['reached']), str(bl['reached'])),
        ("min EE clearance [m]", f"{qp['min_clr']:.3f}", f"{bl['min_clr']:.3f}"),
        ("joint vel violations", f"{qp['v_viol']}", f"{bl['v_viol']}"),
        ("joint accel violations", f"{qp['a_viol']}", f"{bl['a_viol']}"),
        ("QP solver failures", f"{qp['solver_failures']}", "n/a"),
        ("worst solve [ms]", f"{1e3*qp['solve_t'].max():.2f}", "n/a"),
        ("worst full cycle [ms]", f"{1e3*qp['cycle_t'].max():.2f}", "n/a"),
        ("max slack [m]", f"{qp['max_slack']:.4f}", "n/a"),
    ]
    for r in rows:
        print(f"{r[0]:<26}{r[1]:>16}{r[2]:>20}")
    jacobian_error_study()

    try:
        import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
        fig, ax = plt.subplots(2, 2, figsize=(11, 7))
        for j in range(7):
            ax[0, 0].plot(qp['t'], qp['V'][:, j])
        for lim in (-VMAX.max(), VMAX.max()):
            ax[0, 0].axhline(lim, ls='--', c='r', lw=0.8)
        ax[0, 0].set_title("DI-QP joint velocities (within limits)"); ax[0,0].set_xlabel("t[s]"); ax[0,0].set_ylabel("rad/s")
        for j in range(7):
            ax[0, 1].plot(bl['t'], bl['V'][:, j])
        for lim in (-VMAX.max(), VMAX.max()):
            ax[0, 1].axhline(lim, ls='--', c='r', lw=0.8)
        ax[0, 1].set_title(f"baseline joint velocities ({bl['v_viol']} violations)"); ax[0,1].set_xlabel("t[s]")
        cl_qp = [np.linalg.norm(fk(qp['Q'][i]) - obstacle_pos(qp['t'][i])) - R_OBS for i in range(len(qp['t']))]
        cl_bl = [np.linalg.norm(fk(bl['Q'][i]) - obstacle_pos(bl['t'][i])) - R_OBS for i in range(len(bl['t']))]
        ax[1, 0].plot(qp['t'], cl_qp, label='DI-QP'); ax[1, 0].plot(bl['t'], cl_bl, label='baseline')
        ax[1, 0].axhline(R_SAFE - R_OBS, ls='--', c='g', lw=0.8, label='R_safe-R_obs')
        ax[1, 0].set_title("EE clearance"); ax[1,0].set_xlabel("t[s]"); ax[1,0].set_ylabel("m"); ax[1,0].legend()
        ax[1, 1].plot(qp['t'], 1e3*qp['solve_t']); ax[1,1].set_title("DI-QP solve time"); ax[1,1].set_xlabel("t[s]"); ax[1,1].set_ylabel("ms")
        out = RESULTS_DIR / "fr3_dynamic.png"
        fig.tight_layout(); fig.savefig(out, dpi=110)
        print(f"\nsaved {out}")
    except Exception as e:
        print(f"(plot skipped: {e})")


if __name__ == "__main__":
    main()
